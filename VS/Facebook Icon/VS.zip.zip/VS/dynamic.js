/*
	Refactored Code
*/


$(function () {
    var reaction = $('.reacts'),
    var reacts = JSON.parse(reaction)
        like = $('.like');
    reaction.addClass('show');
    like.on('click', function () {
        if (reaction.hasClass('show')) {
            reaction.css({
                'display': 'none',
            });
            reaction.removeClass('show');
        }
        else {
            reaction.css({
                'display': 'flex',
            });
            reaction.addClass('show');
        }
    });
});